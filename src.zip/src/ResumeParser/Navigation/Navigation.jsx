import './Navigation.css';
export default function Navbar(){
    return(
        <div className="navigation">
            <div className="brand">
                <h2>Resume Parser</h2>
            </div>
            <div className="menu">
                <ul className='nav-ul'> 
                    <li className="nav-li">Home</li>
                    <li className="nav-li">About</li>
                    <li className="nav-li">Help</li>
                    <li className="nav-li">Sign</li>
                </ul>
            </div>
        </div>
    )
}